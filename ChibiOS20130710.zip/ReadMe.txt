You must use Arduino 1.5.2 to run ChibiOS on the Arduino Due.

A patch is included for 1.5.1 but it is no longer supported.

documentation.html is a link to the ChibiOS/RT documentation.

the home page for ChibiOS/RT is here:

http://www.chibios.org/dokuwiki/doku.php?id=start

Please read ChibiOS.html for more information on this port.

ChibiOS/RT is version 2.6.0

These libraries were tested with Arduino 1.05 for AVR boards, Arduino 1.5.2
for Due and 1.15 version of the Teensy 3.0 software.

To install these libraries and run the ChibiOS/RT examples, copy the
included libraries to your libraries folder.

The latest version of SdFat is located here:

http://code.google.com/p/sdfatlib/downloads/list

Beta versions are here:

http://code.google.com/p/beta-lib/downloads/list


